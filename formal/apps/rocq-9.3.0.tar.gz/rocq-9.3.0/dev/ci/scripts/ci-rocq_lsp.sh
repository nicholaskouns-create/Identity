#!/usr/bin/env bash

set -e

ci_dir="$(dirname "$0")"
. "${ci_dir}/ci-common.sh"

git_download rocq_lsp

if [ "$DOWNLOAD_ONLY" ]; then exit 0; fi

if [ -n "${GITLAB_CI}" ]; then
  export ROCQLIB="$PWD/_install_ci/lib/coq"
  export ROCQRUNTIMELIB="$PWD/_install_ci/lib/rocq-runtime"
fi

( cd "${CI_BUILD_DIR}/rocq_lsp"
  dune build --root . --only-packages=coq-lsp @install
  # Tests
  _build/install/default/bin/coq-lsp --version
  dune runtest --root . test/serlib
  dune runtest --root . test/compiler
  dune runtest --root . petanque/test
  # It was needed by coq-serapi in CI, we keep it for now
  dune install -p coq-lsp --prefix="$CI_INSTALL_DIR"
)
