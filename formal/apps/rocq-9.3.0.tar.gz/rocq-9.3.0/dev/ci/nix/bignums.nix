{ ocamlPackages }:

{
  buildInputs = [ ocamlPackages.ocaml ];
}
