{ corn }:
{
  coqBuildInputs = [ corn ];
}
