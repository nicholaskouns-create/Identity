{ iris }:
{
  coqBuildInputs = [ iris ];
}
