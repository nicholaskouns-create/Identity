{ stdpp }:
{
  coqBuildInputs = [ stdpp ];
}
