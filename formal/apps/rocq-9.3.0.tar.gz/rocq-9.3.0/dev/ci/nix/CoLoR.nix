{ bignums }:

{
  coqBuildInputs = [ bignums ];
}
