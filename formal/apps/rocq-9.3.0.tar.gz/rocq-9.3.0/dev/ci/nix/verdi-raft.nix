{ Verdi }:
{
  coqBuildInputs = [ Verdi ];
}
