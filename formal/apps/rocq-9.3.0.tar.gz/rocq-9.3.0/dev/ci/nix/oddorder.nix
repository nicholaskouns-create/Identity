{ mathcomp }:
{
  coqBuildInputs = [ mathcomp ];
}
